export class IEmployee{
    id:number;
    name:string;
    email:string;
    username:string;
}